install-sezyo-v2() {
    sudo apt-get update && sudo apt-get install python3-pip golang -y
    pip3 install git-dumper
    GO111MODULE=on go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest

    # Ajout de packages supplémentaires pour la découverte de vulnérabilités
    sudo apt-get install nmap nikto sqlmap dirb -y
    # Ajoutez d'autres outils en fonction de vos besoins

    echo "Installation complete"
}

export PATH=$HOME/.local/bin:$PATH
export PATH=$HOME/go/bin:$PATH

echo "Run install-sezyo-v2 to install"
